using System.Collections.ObjectModel;
using System.Windows.Input;
using Bluepuls_Authoring_Tool.Models;
using Bluepuls_Authoring_Tool.Utilities;

namespace Bluepuls_Authoring_Tool.ViewModels
{
    public class MainViewModel : ObservableObject
    {
        private string _statusMessage = "Check succeeded -- database is consistent! Consistency 0 error(s), 0 warning(s)";
        private string _selectedOdxProject = "Vehicle_Architecture_Gen2.odx-d";
        private string _selectedEcu = "BV_ECM";

        public ObservableCollection<DlcTreeNode> DiagnosticTreeNodes { get; } = new();

        public ObservableCollection<string> OdxProjects { get; } = new()
        {
            "Vehicle_Architecture_Gen2.odx-d",
            "Powertrain_EDC17C69.odx-d",
            "Body_Control_BCM_High.odx-d",
            "ElectricDrive_Inverter_Gen4.odx-d"
        };

        public ObservableCollection<string> EcuList { get; } = new()
        {
            "BV_ECM",
            "BV_RCM",
            "ECM_Bosch_MD1",
            "TCU_9G"
        };

        public ObservableCollection<DiagnosticLogItem> CommunicationLogs { get; } = new();

        public string StatusMessage { get => _statusMessage; set { _statusMessage = value; OnPropertyChanged(); } }
        public string SelectedOdxProject { get => _selectedOdxProject; set { _selectedOdxProject = value; OnPropertyChanged(); } }
        public string SelectedEcu { get => _selectedEcu; set { _selectedEcu = value; OnPropertyChanged(); } }

        public MainViewModel()
        {
            InitializeDlcTreeStructure();
        }

        private void InitializeDlcTreeStructure()
        {
            var rootNode = new DlcTreeNode 
            { 
                Name = "Diagnostic Layer Containers", 
                NodeType = "RootFolder", 
                IsExpanded = true 
            };

            rootNode.Children.Add(new DlcTreeNode { Name = "DLC_SD_UNITS", NodeType = "Container" });
            rootNode.Children.Add(new DlcTreeNode { Name = "DLC_SD_ExP_DOPS", NodeType = "Container" });
            rootNode.Children.Add(new DlcTreeNode { Name = "DLC_SD_DTSJobLibrary", NodeType = "Container" });
            rootNode.Children.Add(new DlcTreeNode { Name = "DLC_SD_DOPS", NodeType = "Container" });
            rootNode.Children.Add(new DlcTreeNode { Name = "DLC_SD_15765_3_Services", NodeType = "Container" });
            rootNode.Children.Add(new DlcTreeNode { Name = "DLC_PR_UDSonCAN", NodeType = "Container" });
            rootNode.Children.Add(new DlcTreeNode { Name = "DLC_BV_RCM", NodeType = "Container" });

            var ecmContainer = new DlcTreeNode 
            { 
                Name = "DLC_BV_ECM", 
                NodeType = "Container", 
                IsExpanded = true 
            };

            ecmContainer.Children.Add(new DlcTreeNode { Name = "Shared Data", NodeType = "Folder" });
            ecmContainer.Children.Add(new DlcTreeNode { Name = "Protocols", NodeType = "Folder" });
            ecmContainer.Children.Add(new DlcTreeNode { Name = "Functional Groups", NodeType = "Folder" });

            var baseVariantsFolder = new DlcTreeNode { Name = "ECU BaseVariants", NodeType = "Folder", IsExpanded = true };
            
            // BV_ECM node with services as children matching the user's latest screenshot request
            var bvNode = new DlcTreeNode 
            { 
                Name = "BV_ECM", 
                NodeType = "BaseVariant", 
                IsExpanded = true,
                IsSelected = true 
            };

            bvNode.Children.Add(new DlcTreeNode { Name = "[22] ReadDataByIdentifier [SD_15765_3_Services]", NodeType = "ServiceGreen" });
            bvNode.Children.Add(new DlcTreeNode { Name = "[22] ReadDataByIdentifier_BootSoftwareIdentification", NodeType = "ServiceGreen" });
            bvNode.Children.Add(new DlcTreeNode { Name = "[22] ReadDataByIdentifier_CalibrationRepairShopCode", NodeType = "ServiceGreen" });
            bvNode.Children.Add(new DlcTreeNode { Name = "[22] ReadDataByIdentifier_ECUSerialNumber", NodeType = "ServiceGreen" });
            bvNode.Children.Add(new DlcTreeNode { Name = "[22] ReadDataByIdentifier_EngineCoolingTemperature", NodeType = "ServiceGreen" });

            baseVariantsFolder.Children.Add(bvNode);
            ecmContainer.Children.Add(baseVariantsFolder);

            ecmContainer.Children.Add(new DlcTreeNode { Name = "ECU Variants", NodeType = "Folder" });

            rootNode.Children.Add(ecmContainer);

            DiagnosticTreeNodes.Add(rootNode);
        }
    }
}