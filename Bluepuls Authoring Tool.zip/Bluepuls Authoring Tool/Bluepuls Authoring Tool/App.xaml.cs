using System.Windows;

namespace Bluepuls_Authoring_Tool
{
    public partial class App : Application
    {
    }
}