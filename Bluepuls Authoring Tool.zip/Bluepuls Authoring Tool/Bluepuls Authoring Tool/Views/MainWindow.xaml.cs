using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Bluepuls_Authoring_Tool.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }

    public class NodeTypeVisibilityConverter : IValueConverter
    {
        public string TargetType { get; set; } = string.Empty;

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string nodeType && nodeType == TargetType)
            {
                return Visibility.Visible;
            }
            return Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}